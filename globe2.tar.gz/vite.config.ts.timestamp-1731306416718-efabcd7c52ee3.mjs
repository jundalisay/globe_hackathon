// vite.config.ts
import { sveltekit } from "file:///home/jun/svelte/saaskit/node_modules/@sveltejs/kit/src/exports/vite/index.js";
import Icons from "file:///home/jun/svelte/saaskit/node_modules/unplugin-icons/dist/vite.js";
import { defineConfig } from "file:///home/jun/svelte/saaskit/node_modules/vitest/dist/config.js";
var vite_config_default = defineConfig({
  plugins: [
    sveltekit(),
    Icons({
      compiler: "svelte",
      autoInstall: true,
      iconCustomizer(collection, icon, props) {
        if (collection === "lucide") {
          props.width = "1.5rem";
          props.height = "1.5rem";
        }
      }
    })
  ],
  test: {
    include: ["src/**/*.{test,spec}.{js,ts}"]
  }
});
export {
  vite_config_default as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsidml0ZS5jb25maWcudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImNvbnN0IF9fdml0ZV9pbmplY3RlZF9vcmlnaW5hbF9kaXJuYW1lID0gXCIvaG9tZS9qdW4vc3ZlbHRlL3NhYXNraXRcIjtjb25zdCBfX3ZpdGVfaW5qZWN0ZWRfb3JpZ2luYWxfZmlsZW5hbWUgPSBcIi9ob21lL2p1bi9zdmVsdGUvc2Fhc2tpdC92aXRlLmNvbmZpZy50c1wiO2NvbnN0IF9fdml0ZV9pbmplY3RlZF9vcmlnaW5hbF9pbXBvcnRfbWV0YV91cmwgPSBcImZpbGU6Ly8vaG9tZS9qdW4vc3ZlbHRlL3NhYXNraXQvdml0ZS5jb25maWcudHNcIjtpbXBvcnQgeyBzdmVsdGVraXQgfSBmcm9tICdAc3ZlbHRlanMva2l0L3ZpdGUnO1xuaW1wb3J0IEljb25zIGZyb20gJ3VucGx1Z2luLWljb25zL3ZpdGUnO1xuaW1wb3J0IHsgZGVmaW5lQ29uZmlnIH0gZnJvbSAndml0ZXN0L2NvbmZpZyc7XG5cbmV4cG9ydCBkZWZhdWx0IGRlZmluZUNvbmZpZyh7XG5cdHBsdWdpbnM6IFtcblx0XHRzdmVsdGVraXQoKSxcblx0XHRJY29ucyh7XG5cdFx0XHRjb21waWxlcjogJ3N2ZWx0ZScsXG5cdFx0XHRhdXRvSW5zdGFsbDogdHJ1ZSxcblx0XHRcdGljb25DdXN0b21pemVyKGNvbGxlY3Rpb24sIGljb24sIHByb3BzKSB7XG5cdFx0XHRcdC8vIGN1c3RvbWl6ZSBhbGwgaWNvbnMgaW4gdGhpcyBjb2xsZWN0aW9uXG5cdFx0XHRcdGlmIChjb2xsZWN0aW9uID09PSAnbHVjaWRlJykge1xuXHRcdFx0XHRcdHByb3BzLndpZHRoID0gJzEuNXJlbSc7XG5cdFx0XHRcdFx0cHJvcHMuaGVpZ2h0ID0gJzEuNXJlbSc7XG5cdFx0XHRcdH1cblx0XHRcdH0sXG5cdFx0fSksXG5cdF0sXG5cdHRlc3Q6IHtcblx0XHRpbmNsdWRlOiBbJ3NyYy8qKi8qLnt0ZXN0LHNwZWN9Lntqcyx0c30nXSxcblx0fSxcbn0pO1xuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUEwUCxTQUFTLGlCQUFpQjtBQUNwUixPQUFPLFdBQVc7QUFDbEIsU0FBUyxvQkFBb0I7QUFFN0IsSUFBTyxzQkFBUSxhQUFhO0FBQUEsRUFDM0IsU0FBUztBQUFBLElBQ1IsVUFBVTtBQUFBLElBQ1YsTUFBTTtBQUFBLE1BQ0wsVUFBVTtBQUFBLE1BQ1YsYUFBYTtBQUFBLE1BQ2IsZUFBZSxZQUFZLE1BQU0sT0FBTztBQUV2QyxZQUFJLGVBQWUsVUFBVTtBQUM1QixnQkFBTSxRQUFRO0FBQ2QsZ0JBQU0sU0FBUztBQUFBLFFBQ2hCO0FBQUEsTUFDRDtBQUFBLElBQ0QsQ0FBQztBQUFBLEVBQ0Y7QUFBQSxFQUNBLE1BQU07QUFBQSxJQUNMLFNBQVMsQ0FBQyw4QkFBOEI7QUFBQSxFQUN6QztBQUNELENBQUM7IiwKICAibmFtZXMiOiBbXQp9Cg==
