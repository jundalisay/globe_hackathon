## Globe Hackathon Table 5

- SvelteKit 2.5.20
- Svelte 4.0.2

Tailwind, shadcn-svelte, Postgres, and Supabase.

> Based on [CriticalMoments/CMSaasStarter](https://github.com/CriticalMoments/CMSaasStarter) by the folks at [Critical Moments](https://criticalmoments.io)!


