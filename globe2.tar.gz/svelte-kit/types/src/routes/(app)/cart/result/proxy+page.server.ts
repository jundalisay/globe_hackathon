// @ts-nocheck
import type { PostgrestError } from '@supabase/supabase-js';
import { fail, type PageServerData, type Actions, type ServerLoad } from '@sveltejs/kit';


export const load = async ({ locals, url }: Parameters<PageServerData>[0]) => {
	const { user } = await locals.safeGetSession();

	// return { };
};

