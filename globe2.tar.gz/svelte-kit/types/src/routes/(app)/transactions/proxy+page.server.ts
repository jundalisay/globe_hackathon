// @ts-nocheck
import type { PageServerData } from './$types';
import type { PostgrestError } from '@supabase/supabase-js';
import { fail, type Actions, type ServerLoad } from '@sveltejs/kit';


export const load = async ({ locals, url }: Parameters<PageServerData>[0]) => {
	const { user } = await locals.safeGetSession();

	const { data } = await locals.supabase.from('transactions').select('*');

	console.log('Page Server Ts transactions: ', data);

	// console.log('Searched is: ', searched);	

	return { transactions: data };
};
