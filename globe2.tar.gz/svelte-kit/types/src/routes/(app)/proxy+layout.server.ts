// @ts-nocheck
import { redirect } from '@sveltejs/kit';
import type { LayoutServerLoad } from './$types';

export const load = async ({ locals: { safeGetSession }, }: Parameters<LayoutServerLoad>[0]) => {
	const { session } = await safeGetSession();

	if (!session) {
		redirect(303, '/login');
	}
};
