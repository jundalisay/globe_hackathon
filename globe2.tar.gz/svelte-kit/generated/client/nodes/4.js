import * as universal from "../../../../src/routes/(auth)/+layout.ts";
export { universal };
export { default as component } from "../../../../src/routes/(auth)/+layout.svelte";