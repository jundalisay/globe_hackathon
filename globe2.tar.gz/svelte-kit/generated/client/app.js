export { matchers } from './matchers.js';

export const nodes = [
	() => import('./nodes/0'),
	() => import('./nodes/1'),
	() => import('./nodes/2'),
	() => import('./nodes/3'),
	() => import('./nodes/4'),
	() => import('./nodes/5'),
	() => import('./nodes/6'),
	() => import('./nodes/7'),
	() => import('./nodes/8'),
	() => import('./nodes/9'),
	() => import('./nodes/10'),
	() => import('./nodes/11'),
	() => import('./nodes/12'),
	() => import('./nodes/13'),
	() => import('./nodes/14'),
	() => import('./nodes/15'),
	() => import('./nodes/16'),
	() => import('./nodes/17'),
	() => import('./nodes/18'),
	() => import('./nodes/19'),
	() => import('./nodes/20'),
	() => import('./nodes/21'),
	() => import('./nodes/22'),
	() => import('./nodes/23'),
	() => import('./nodes/24'),
	() => import('./nodes/25'),
	() => import('./nodes/26'),
	() => import('./nodes/27'),
	() => import('./nodes/28'),
	() => import('./nodes/29'),
	() => import('./nodes/30'),
	() => import('./nodes/31'),
	() => import('./nodes/32'),
	() => import('./nodes/33'),
	() => import('./nodes/34')
];

export const server_loads = [0,2,4];

export const dictionary = {
		"/(app)": [~5,[2]],
		"/(app)/cart": [~6,[2]],
		"/(app)/cart/result": [~7,[2]],
		"/(app)/checkout": [8,[2]],
		"/(auth)/forgot-password": [~31,[4]],
		"/(app)/items": [~9,[2]],
		"/(app)/items/new": [~12,[2]],
		"/(app)/items/[id]": [~10,[2]],
		"/(app)/items/[id]/edit": [~11,[2]],
		"/(app)/log-out": [13,[2]],
		"/login": [~34],
		"/(app)/orgs": [~14,[2]],
		"/(app)/orgs/new": [~17,[2]],
		"/(app)/orgs/[id]/delete": [~15,[2]],
		"/(app)/orgs/[id]/edit": [~16,[2]],
		"/(app)/points": [~18,[2]],
		"/(auth)/register": [~32,[4]],
		"/(auth)/security-error": [33,[4]],
		"/(app)/services": [~19,[2]],
		"/(app)/services/new": [~22,[2]],
		"/(app)/services/[id]": [~20,[2]],
		"/(app)/services/[id]/edit": [~21,[2]],
		"/(app)/settings": [~23,[2,3]],
		"/(app)/settings/profile": [~24,[2,3]],
		"/(app)/settings/security": [~25,[2,3]],
		"/(app)/transactions": [~26,[2]],
		"/(app)/transactions/[id]": [~27,[2]],
		"/(app)/users": [~28,[2]],
		"/(app)/users/[id]": [~29,[2]],
		"/(app)/wizard": [~30,[2]]
	};

export const hooks = {
	handleError: (({ error }) => { console.error(error) }),

	reroute: (() => {})
};

export { default as root } from '../root.svelte';