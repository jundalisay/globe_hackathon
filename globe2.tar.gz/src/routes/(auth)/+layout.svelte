<div class="mx-auto flex max-w-screen-lg flex-col items-center">
	<div>
		<slot />
	</div>
</div>
