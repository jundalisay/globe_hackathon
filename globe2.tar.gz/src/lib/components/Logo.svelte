<script lang="ts">
	import { cn } from '$lib/utils';
</script>

<div
	role="img"
	aria-label="SaaS Kit logo"
	class={cn(
		'aspect-square size-6',
		'flex flex-col items-center justify-center',
		'bg-primary text-primary-foreground',
		'-rotate-12 rounded font-bold',
		'text-xs',
		'[&_*]:mt-[-2px] [&_*]:leading-[0.85]',
	)}
>
	<span>sa</span>
	<span>as</span>
</div>
