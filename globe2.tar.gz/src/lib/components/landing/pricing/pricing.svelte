<script lang="ts">
	import { cn } from '$lib/utils';
</script>

<div class={cn('grid gap-2 md:grid-cols-3')}>
	<slot />
</div>
