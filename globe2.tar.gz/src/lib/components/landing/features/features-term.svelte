<script lang="ts">
	import { cn } from '$lib/utils';
</script>

<dt class={cn('text-2xl font-bold', $$props.class)}>
	<slot />
</dt>
