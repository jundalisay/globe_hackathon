import Logo from './logos-cloud-logo.svelte';
import Root from './logos-cloud.svelte';

export { Logo, Root as LogosCloud, Logo as LogosCloudLogo, Root };
