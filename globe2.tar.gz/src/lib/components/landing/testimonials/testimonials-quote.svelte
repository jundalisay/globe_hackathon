<blockquote class="hyphens-auto whitespace-pre-wrap break-words">
	<slot />
</blockquote>
