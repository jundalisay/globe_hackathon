<script lang="ts">
</script>

<!-- eslint-disable-next-line svelte/valid-compile -->
<!-- svelte-ignore a11y-structure -->
<figcaption>
	<slot />
</figcaption>
