<figure class="md:break-inside-avoid">
	<slot />
</figure>
