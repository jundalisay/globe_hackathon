<header class="flex flex-col items-center gap-2">
	<slot />
</header>
