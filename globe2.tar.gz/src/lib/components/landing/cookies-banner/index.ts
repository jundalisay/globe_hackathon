export { default as CookiesBanner } from './cookies-banner.svelte';
